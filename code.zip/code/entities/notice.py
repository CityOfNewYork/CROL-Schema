from jsl import Document, ArrayField, DocumentField
from .skeleton import Skeleton
from .noticeitem import NoticeItem
from .address import Address


class Notice(Document):
    class Options(object):
        title = 'Notice'
        description = 'Noticm nijojopjpojpojoe type'
        definition_id = 'notices'

    doc = DocumentField(Skeleton, as_ref=True)
    address = DocumentField(Address, as_ref=True)
    items = ArrayField(NoticeItem)
