from jsl import Document, StringField, IntField, DateTimeField
from jsl import DocumentField
from .noticeType import NoticeType
from .sectionName import SectionName
from .organization import Organization

class Skeleton(Document):

    class Options(object):
        title = 'NoticeBase'
        definition_id = 'basenotice'
        description = 'The notice skeleton that is part of the response for each notice. Includes the normalized and standardized fields that are available to all'
'''
    noticeDate = DateTimeField(description='sampleValue: An ISO 8601 formatted date-time field. \nmappedField: Time_Submitted \naction: 1 \ncomment: incl')
    noticeId = StringField(required=True,description='sampleValue: 20130621104 \nmappedField: RequestID \naction: 1 \ncomment: incl')
    noticeType = DocumentField(NoticeType, as_ref=True)
    sectionName = DocumentField(SectionName, as_ref=True)
    noticeDescription = StringField(description='sampleValue: Hello world! \nmappedField: AdditionalDescription \naction: 0 \ncomment: incl')
    otherInfo = StringField(description='sampleValue: The services cannot be timely procured through competitive sealed..."" \nmappedField: PrintOut \naction: 0 \ncomment: incl')
    printOut = StringField(description='sampleValue: CITRIX XENAPP ENTERPRISE SOFTWARE \nmappedField: PrintOut \naction: 0 \ncomment: incl')
    organization = DocumentField(Organization, as_ref=True)
    noticeStartDate = DateTimeField(description='sampleValue: An ISO 8601 formatted date-time field. \nmappedField: StartDate \naction: 0 \ncomment: incl')
    noticeEndDate = DateTimeField(description='sampleValue: An ISO 8601 formatted date-time field. \nmappedField: EndDate \naction: 0 \ncomment: incl')