from jsl import Document, StringField, IntField


class SectionName(Document):
    class Options(object):
        title = 'SectionName'
        description = 'The type of notices available.\n For DCAS, see proc_Type_of_Notice for possible values'
        definition_id = 'SectionName'

    id = IntField(description='The reference ID of the CR section ')
    name = StringField(description='sampleValue: Court Notices \nmappedField: proc_Sections \naction: 1 \ncomment: incl')	